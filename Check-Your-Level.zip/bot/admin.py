from bot.models import TgUser, Category, Product
from django.contrib import admin

# Register your models here.
admin.site.register(TgUser)
admin.site.register(Category)
admin.site.register(Product)
