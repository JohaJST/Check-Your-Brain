# import datetime
#
# a = datetime.date.today()
# print(a.isoformat())
# # print(a.iso)









# num = 1
# summ = 1
# b = 0
# for i in range(1, 8 + 1):
#     for j in range(1, i + 1):
#         num *= 3
#     summ += 1 / num
#     num = 1
# print(summ)

