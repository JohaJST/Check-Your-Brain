from .auth import User, Otp, TG_User
from .classrooms import ClassRooms
from .Quiz import Quiz, Subject, Variant, AllTests, CompletedTest, Tests
